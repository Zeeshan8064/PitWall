interface DriverCardProps {
  driver: {
    driverNumber: number;
    acronym: string;
    fullName: string;
    team: string;
    teamColour: string;
    headshotUrl: string;
  };
}

export default function DriverCard({ driver }: DriverCardProps) {
  return (
    <button
      className="group relative h-[520px] overflow-hidden rounded-[28px] border border-neutral-800 bg-[#111111] text-left transition-all duration-500 hover:-translate-y-2 hover:border-neutral-600"
      style={{
        boxShadow: `0 0 0 rgba(0,0,0,0)`,
      }}
    >
      {/* Team Glow */}
      <div
        className="absolute inset-0 opacity-20 transition duration-500 group-hover:opacity-40"
        style={{
          background: `radial-gradient(circle at 50% 20%, ${driver.teamColour}, transparent 70%)`,
        }}
      />

      {/* Carbon texture */}
      <div
        className="absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "repeating-linear-gradient(45deg,#fff 0,#fff 1px,transparent 1px,transparent 8px)",
        }}
      />

      {/* Driver Number */}
      <div
        className="absolute left-6 top-6 z-20 rounded-2xl border border-neutral-700 px-5 py-3"
        style={{
          background: "#151515",
        }}
      >
        <p className="text-5xl font-black leading-none">
          {driver.driverNumber}
        </p>

        <p className="mt-1 text-xs uppercase tracking-[0.25em] text-neutral-500">
          Driver
        </p>
      </div>

      {/* Driver Image */}
      <img
        src={driver.headshotUrl}
        alt={driver.fullName}
        className="absolute right-0 top-4 h-[105%] object-contain transition duration-500 group-hover:scale-105"
      />

      {/* Gradient */}
      <div className="absolute inset-x-0 bottom-0 h-64 bg-gradient-to-t from-[#0A0A0A] via-[#0A0A0Add] to-transparent" />

      {/* Bottom */}
      <div className="absolute bottom-0 left-0 right-0 z-20 p-7">

        <div className="flex items-end justify-between">

          <div>

            <h2 className="text-6xl font-black tracking-tight">
              {driver.acronym}
            </h2>

            <p
              className="mt-2 text-sm font-semibold uppercase tracking-[0.2em]"
              style={{
                color: driver.teamColour,
              }}
            >
              {driver.team}
            </p>

          </div>

          <div
            className="rounded-full border px-4 py-2 text-xs uppercase tracking-[0.2em]"
            style={{
              borderColor: driver.teamColour,
              color: driver.teamColour,
            }}
          >
            View
          </div>

        </div>

        <div className="mt-6 grid grid-cols-3 border-t border-neutral-800 pt-5">

          <div>
            <p className="text-2xl font-black">--</p>
            <p className="mt-1 text-[11px] uppercase tracking-widest text-neutral-500">
              Wins
            </p>
          </div>

          <div>
            <p className="text-2xl font-black">--</p>
            <p className="mt-1 text-[11px] uppercase tracking-widest text-neutral-500">
              Podiums
            </p>
          </div>

          <div>
            <p className="text-2xl font-black">--</p>
            <p className="mt-1 text-[11px] uppercase tracking-widest text-neutral-500">
              Poles
            </p>
          </div>

        </div>

      </div>

      {/* Corner Cut */}
      <div
        className="absolute bottom-0 right-0 h-16 w-16"
        style={{
          background:
            "linear-gradient(135deg, transparent 49%, #0A0A0A 50%)",
        }}
      />
    </button>
  );
}