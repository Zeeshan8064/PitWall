import mongoose from "mongoose";

const pitStopSchema = new mongoose.Schema(
  {
    race: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Race",
      required: true,
      index: true,
    },

    driver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Driver",
      required: true,
      index: true,
    },

    lap: {
      type: Number,
      required: true,
    },

    date: {
      type: Date,
      required: true,
    },

    laneDuration: {
      type: Number,
      required: true,
    },

    pitDuration: {
      type: Number,
      required: true,
    },

    stopDuration: {
      type: Number,
      required: true,
    },

    fromCompound: {
      type: String,
      enum: ["SOFT", "MEDIUM", "HARD", "INTERMEDIATE", "WET"],
    },

    toCompound: {
      type: String,
      enum: ["SOFT", "MEDIUM", "HARD", "INTERMEDIATE", "WET"],
    },
  },
  {
    timestamps: true,
  }
);

// One pit stop per driver per lap per race
pitStopSchema.index(
  { race: 1, driver: 1, lap: 1 },
  { unique: true }
);

export default mongoose.model("PitStop", pitStopSchema);