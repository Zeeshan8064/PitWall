import mongoose from "mongoose";


const driverSchema = new mongoose.Schema(
  {
    driverNumber: {
      type: Number,
      required: true,
      unique: true,
    },

    firstName: {
      type: String,
      required: true,
    },

    lastName: {
      type: String,
      required: true,
    },

    abbreviation: {
      type: String,
    },

    nationality: {
      type: String,
    },

    team: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Team",
    },
  },
  {
    timestamps: true,
  }
);


export default mongoose.model(
  "Driver",
  driverSchema
);