import mongoose from "mongoose";

const lapSchema = new mongoose.Schema(
  {
    race: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Race",
      required: true,
      index: true,
    },

    driver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Driver",
      required: true,
      index: true,
    },

    lapNumber: {
      type: Number,
      required: true,
    },

    lapDuration: {
      type: Number,
      required: true,
    },
    compound: {
      type: String,
      enum: ["SOFT", "MEDIUM", "HARD", "INTERMEDIATE", "WET"],
      required: true,
    },
    stSpeed: {
  type: Number,
},

    durationSector1: Number,

    durationSector2: Number,

    durationSector3: Number,

    position: Number,

    isPitOutLap: Boolean,

    dateStart: Date,
  },
  {
    timestamps: true,
  },
);

// One lap per driver per race
lapSchema.index({ race: 1, driver: 1, lapNumber: 1 }, { unique: true });

export default mongoose.model("Lap", lapSchema);
