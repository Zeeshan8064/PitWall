import {
  getDrivers,
  getIntervals,
  getLaps,
  getPitstops,
  getStints,
} from ".";

export async function getRaceData(sessionKey: number) {

  console.log("==========");
  console.log("Session:", sessionKey);

  console.log("Fetching Drivers...");
  const drivers = await getDrivers(sessionKey);
  console.log("✓ Drivers:", drivers.length);

  console.log("Fetching Laps...");
  const laps = await getLaps(sessionKey);
  console.log("✓ Laps:", laps.length);

  console.log("Fetching Stints...");
  const stints = await getStints(sessionKey);
  console.log("✓ Stints:", stints.length);

  console.log("Fetching Pitstops...");
  const pitstops = await getPitstops(sessionKey);
  console.log("✓ Pitstops:", pitstops.length);

  console.log("Fetching Intervals...");
  const intervals = await getIntervals(sessionKey);
  console.log("✓ Intervals:", intervals.length);

  return {
    drivers,
    laps,
    stints,
    pitstops,
    intervals,
  };
}