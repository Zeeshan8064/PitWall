import mongoose from "mongoose";

const raceResultSchema = new mongoose.Schema(
  {
    race: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Race",
      required: true,
      index: true,
    },

    driver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Driver",
      required: true,
      index: true,
    },

    gridPosition: {
      type: Number,
      required: true,
    },

    finishPosition: {
      type: Number,
      required: true,
      index: true,
    },

    points: {
      type: Number,
      required: true,
    },

    status: {
      type: String,
      required: true,
    },

    gapToLeader: {
      type: String,
    },

    finishTime: {
      type: String,
    },

    finalCompound: {
      type: String,
      enum: ["SOFT", "MEDIUM", "HARD", "INTERMEDIATE", "WET"],
    },
  },
  {
    timestamps: true,
  }
);

raceResultSchema.index(
  { race: 1, driver: 1 },
  { unique: true }
);

export default mongoose.model("RaceResult", raceResultSchema);