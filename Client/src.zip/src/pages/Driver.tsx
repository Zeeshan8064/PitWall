import Navbar from "../components/Navbar";
import DriverCard from "./DriverCard";
export default function Drivers() {
  return (
    <>
      <Navbar />
      <main className="min-h-screen bg-[#0A0A0A] text-white pt-8.5">
        {/* Hero */}
        <section className="relative overflow-hidden border-b border-neutral-900">
          {/* Background glow */}
          <div className="absolute left-1/2 top-0 h-125 w-125 -translate-x-1/2 rounded-full bg-red-600/10 blur-3xl" />

          {/* Background text */}
          <h2 className="pointer-events-none absolute left-1/2 top-10 -translate-x-1/2 whitespace-nowrap text-[220px] font-black uppercase tracking-tight text-white/3">
            HELMET
          </h2>

          <div className="relative mx-auto flex max-w-7xl flex-col items-center px-8 pt-24 pb-12 text-center">
            <p className="text-xs font-bold uppercase tracking-[0.5em] text-red-500">
              Driver Archive
            </p>

            <h1 className="mt-5 text-6xl font-black uppercase leading-[0.9] md:text-8xl">
              BEYOND
              <br />
              <span className="text-white">THE HELMET.</span>
            </h1>

            <p className="mt-8 max-w-2xl text-lg leading-8 text-neutral-400">
              Precision. Performance. Consistency. Discover every driver through
              data that goes beyond the final result.
            </p>

            <div className="mt-14 flex items-center gap-10 text-center">
              <div>
                <p className="text-4xl font-black text-white">22</p>
                <p className="mt-1 text-[11px] uppercase tracking-[0.3em] text-neutral-500">
                  Drivers
                </p>
              </div>

              <div className="h-10 w-px bg-neutral-800" />

              <div>
                <p className="text-4xl font-black text-white">11</p>
                <p className="mt-1 text-[11px] uppercase tracking-[0.3em] text-neutral-500">
                  Teams
                </p>
              </div>

              <div className="h-10 w-px bg-neutral-800" />

              <div>
                <p className="text-4xl font-black text-white">24</p>
                <p className="mt-1 text-[11px] uppercase tracking-[0.3em] text-neutral-500">
                  Races
                </p>
              </div>
            </div>

            <div className="mt-14 flex items-center gap-3 text-sm uppercase tracking-[0.35em] text-neutral-500">
              <span className="h-px w-10 bg-neutral-700" />
              Scroll to explore
              <span className="h-px w-10 bg-neutral-700" />
            </div>
            <div className="mx-auto mt-20 max-w-7xl">
  <div className="grid gap-8 md:grid-cols-2">
    {drivers.map((driver) => (
      <DriverCard
        key={driver.driverNumber}
        driver={driver}
      />
    ))}
  </div>
</div>
          </div>

        </section>
      </main>
    </>
  );
}
