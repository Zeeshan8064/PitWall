import { OPENF1_BASE, REQUEST_DELAY } from "../constants/api";

function delay(ms: number) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Fetch data from OpenF1 while respecting
 * the API rate limit.
 */
export async function fetchOpenF1<T>(endpoint: string): Promise<T[]> {
  await delay(REQUEST_DELAY);

  const url = `${OPENF1_BASE}${endpoint}`;

  console.log("OpenF1 URL:", url);

  const response = await fetch(url);

  console.log("Status:", response.status);

  if (!response.ok) {
    const text = await response.text();
    console.log(text);
    throw new Error(`OpenF1 request failed (${response.status})`);
  }

  return response.json() as Promise<T[]>;
}