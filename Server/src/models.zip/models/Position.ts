import mongoose from "mongoose";

const positionSchema = new mongoose.Schema(
  {
    race: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Race",
      required: true,
      index: true,
    },

    driver: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Driver",
      required: true,
      index: true,
    },

    lapNumber: {
      type: Number,
      required: true,
    },

    position: {
      type: Number,
      required: true,
    },

    date: {
      type: Date,
    },
  },
  {
    timestamps: true,
  }
);

// One position per driver per lap
positionSchema.index(
  { race: 1, driver: 1, lapNumber: 1 },
  { unique: true }
);

export default mongoose.model("Position", positionSchema);